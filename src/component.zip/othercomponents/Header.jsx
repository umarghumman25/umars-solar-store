import React, { Component } from 'react';
import img2 from './image/login.jpg';
import img3 from './image/logo.PNG';
import { NavLink } from 'react-router-dom';
import './styles/Main.css';
import Search from "../common/header/Search"

const Header = ({ CartItem }) => {
    return (
        <>
            <header>
                <div className="flex" >
                    <div className="logo" > <img src={img3} alt={img2} /></div >
                    <div className="iteam" ><NavLink className="s" to="/Home"> Home</NavLink> </div>
                    <div className="iteam" ><NavLink className="s" to="/Services"> Services</NavLink>  </div>
                    <div className="iteam" > <NavLink className="s" to="/Store"> Store</NavLink> </div>
                    <div className="iteam" >  <NavLink className="s" to="/About"> About</NavLink> </div>
                    <div className="person" >  <select name="point-1" id="point-1">
                        <option>Shahzaib</option>
                        <option>N/A</option>
                        <option>N/A</option>
                        <option>N/A</option>
                    </select></div>
                </div>
            </header>
            <Search CartItem={CartItem} />

        </>
    )
}
export default Header;