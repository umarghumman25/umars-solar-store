import React, { useState } from 'react';
import loginimg1 from './image/login4.jpg';
import loginimg2 from './image/login2.webp'
import dummy from './image/login4.jpg';
import { Link } from 'react-router-dom';
// import { FaFacebook, FaInstagram, FaTwitter, FaLock } from 'react-icons/fa';
// import { HiMail } from "react-icons/hi";
import './styles/login.css';


const Login = () => {
    // const navigate = useNavigate();
    const [inputFields, setInputFields] = useState([
        { name: 'null' }, { password: 'null' }

    ]

    )
    const handleFormChange = (index, e) => {


        let data = [...inputFields];
        if (index === 0) {

            data[0].name = e.target.value
            setInputFields(data);

        }

        else {
            data[1].password = e.target.value
            setInputFields(data);

        }
    }




    const submit = (e) => {
        e.preventDefault();
        const data = {
            name: inputFields[0].name,
            password: inputFields[1].password
        }

        for (let i in data) {
            console.log(data[i])
        }
        // navigate("/home")

        return 0;
    }





    return (
        <>

            <div className="login-container">
                <div className="login-image"><img src={loginimg1} alt={dummy}></img></div>



                <div className="login">

                    <div className="login-header">About</div>
                    <div className="login-header">Services</div>
                    <div className="login-header">Contact</div>
                </div>

                <div className="login-form">

                    <div className="login-input">
                        <div className="login-image2"><img src={loginimg2} alt={dummy}></img></div>
                        <div className="login-heading">Welcome!</div>
                        <div className="login-subheading">To Our New Website.</div>
                        <div className="login-smallheading">Solution to All your problems</div>
                        <div className="login-socialicons">
                            <div className="facebook">
                                {/* <FaFacebook /> */}
                            </div>
                            <div className="insta">
                                {/* <FaInstagram /> */}
                            </div>
                            <div className="twitter">
                                {/* <FaTwitter /> */}
                            </div>

                        </div>

                    </div>

                    <div className="login-input1">

                        <div className="login-formhead">User Login </div>
                        <div className="login-element"><input type="email" name='name' placeholder="Email"
                            onChange={e => handleFormChange(0, e)} /><span className="mailicon">
                            </span></div>
                        <div className="login-element"> <input type="password" name='password' placeholder="Password"
                            onChange={e => handleFormChange(1, e)} /><span className="iconn">
                            </span></div>
                        <div className="login-forpass">Forget Password?</div>
                        <div className="login-element"><button onClick={submit}>Sign In</button>
                        </div>
                        <div className="login-signup">Don't have an account? <Link className="me" to="/CreateAccount"><span className="es">Sign up</span></Link></div>
                        <Link className="me" to="/Login1"><div className="loginoption">Login As Admin</div></Link>
                    </div>

                </div>
            </div>

        </>
    )
}



export default Login;